
const story = [
  "Bir gün erkek TikTok izliyordu... 📱",
  "Karşısına bir video çıktı.",
  "Video kızındı 👀",
  "Profiline girdi.",
  "Instagram hesabını gördü.",
  "İstek attı 💌",
  "İstek kabul edildi.",
  "İlk mesaj geldi...",
  "“Sen kimsin?” 😄",
  "Ve her şey böyle başladı 🧱❤️"
];

let step = 0;
const textEl = document.getElementById("storyText");
const finalEl = document.getElementById("final");
const music = document.getElementById("bgMusic");

function nextStep() {
  if (step < story.length) {
    textEl.textContent = story[step];
    step++;
  } else {
    finalEl.style.display = "flex";
  }
}

// swipe
let startX = 0;
document.addEventListener("touchstart", e => startX = e.touches[0].clientX);
document.addEventListener("touchend", e => {
  const endX = e.changedTouches[0].clientX;
  if (startX - endX < -50) nextStep();
});

// iOS audio fix
function startAudio() {
  if (music.paused) music.play();
}
